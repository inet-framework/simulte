//
// Copyright (C) OpenSim Ltd.
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this program; if not, see <http://www.gnu.org/licenses/>.
//

#ifndef __INET_NETWORKNODECANVASVISUALIZATION_H
#define __INET_NETWORKNODECANVASVISUALIZATION_H

#include "inet/common/figures/cPanelFigure.h"
#include "inet/visualizer/util/Displacement.h"

namespace inet {

namespace visualizer {

class INET_API NetworkNodeCanvasVisualization : public cGroupFigure
{
  protected:
    class INET_API Annotation {
      public:
        cFigure *figure;
        cFigure::Rectangle bounds;
        Displacement displacementHint;
        double displacementPriority;

      public:
        Annotation(cFigure *figure, const cFigure::Point& size, Displacement displacement, double displacementPriority);

        static bool compareDisplacementPriority(const Annotation& a1, const Annotation& a2);
    };

  protected:
    cModule *networkNode = nullptr;
    double annotationSpacing = NaN;
    double displacementPenalty = NaN;

    bool isLayoutInvalid = false;
    cFigure::Rectangle submoduleBounds;
    std::vector<Annotation> annotations;
    cPanelFigure *annotationFigure = nullptr;

  protected:
    virtual void layout();

  public:
    NetworkNodeCanvasVisualization(cModule *networkNode, double annotationSpacing, double displacementPenalty);

    virtual void refreshDisplay() override;

    virtual void addAnnotation(cFigure *figure, cFigure::Point size, Displacement displacement = DISPLACEMENT_ANY, double displacementPriority = 0);
    virtual void removeAnnotation(cFigure *figure);
    virtual void setAnnotationSize(cFigure *figure, cFigure::Point size);
    virtual void setAnnotationVisible(cFigure *figure, bool visible);
};

} // namespace visualizer

} // namespace inet

#endif // ifndef __INET_NETWORKNODECANVASVISUALIZATION_H

