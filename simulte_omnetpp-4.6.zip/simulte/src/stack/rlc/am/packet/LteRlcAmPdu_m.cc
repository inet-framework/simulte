//
// Generated file, do not edit! Created by nedtool 4.6 from stack/rlc/am/packet/LteRlcAmPdu.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "LteRlcAmPdu_m.h"

USING_NAMESPACE


// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




// Template rule for outputting std::vector<T> types
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');
    
    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

LteRlcAmPdu_Base::LteRlcAmPdu_Base(const char *name, int kind) : ::LteRlcPdu(name,kind)
{
    this->amType_var = 0;
    this->txNumber_var = 0;
    this->firstSn_var = 0;
    this->lastSn_var = 0;
}

LteRlcAmPdu_Base::LteRlcAmPdu_Base(const LteRlcAmPdu_Base& other) : ::LteRlcPdu(other)
{
    copy(other);
}

LteRlcAmPdu_Base::~LteRlcAmPdu_Base()
{
}

LteRlcAmPdu_Base& LteRlcAmPdu_Base::operator=(const LteRlcAmPdu_Base& other)
{
    if (this==&other) return *this;
    ::LteRlcPdu::operator=(other);
    copy(other);
    return *this;
}

void LteRlcAmPdu_Base::copy(const LteRlcAmPdu_Base& other)
{
    this->amType_var = other.amType_var;
    this->txNumber_var = other.txNumber_var;
    this->firstSn_var = other.firstSn_var;
    this->lastSn_var = other.lastSn_var;
}

void LteRlcAmPdu_Base::parsimPack(cCommBuffer *b)
{
    ::LteRlcPdu::parsimPack(b);
    doPacking(b,this->amType_var);
    doPacking(b,this->txNumber_var);
    doPacking(b,this->firstSn_var);
    doPacking(b,this->lastSn_var);
    // field bitmap is abstract -- please do packing in customized class
}

void LteRlcAmPdu_Base::parsimUnpack(cCommBuffer *b)
{
    ::LteRlcPdu::parsimUnpack(b);
    doUnpacking(b,this->amType_var);
    doUnpacking(b,this->txNumber_var);
    doUnpacking(b,this->firstSn_var);
    doUnpacking(b,this->lastSn_var);
    // field bitmap is abstract -- please do unpacking in customized class
}

unsigned short LteRlcAmPdu_Base::getAmType() const
{
    return amType_var;
}

void LteRlcAmPdu_Base::setAmType(unsigned short amType)
{
    this->amType_var = amType;
}

unsigned short LteRlcAmPdu_Base::getTxNumber() const
{
    return txNumber_var;
}

void LteRlcAmPdu_Base::setTxNumber(unsigned short txNumber)
{
    this->txNumber_var = txNumber;
}

int LteRlcAmPdu_Base::getFirstSn() const
{
    return firstSn_var;
}

void LteRlcAmPdu_Base::setFirstSn(int firstSn)
{
    this->firstSn_var = firstSn;
}

int LteRlcAmPdu_Base::getLastSn() const
{
    return lastSn_var;
}

void LteRlcAmPdu_Base::setLastSn(int lastSn)
{
    this->lastSn_var = lastSn;
}

class LteRlcAmPduDescriptor : public cClassDescriptor
{
  public:
    LteRlcAmPduDescriptor();
    virtual ~LteRlcAmPduDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(LteRlcAmPduDescriptor);

LteRlcAmPduDescriptor::LteRlcAmPduDescriptor() : cClassDescriptor("LteRlcAmPdu", "LteRlcPdu")
{
}

LteRlcAmPduDescriptor::~LteRlcAmPduDescriptor()
{
}

bool LteRlcAmPduDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<LteRlcAmPdu_Base *>(obj)!=NULL;
}

const char *LteRlcAmPduDescriptor::getProperty(const char *propertyname) const
{
    if (!strcmp(propertyname,"customize")) return "true";
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int LteRlcAmPduDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 5+basedesc->getFieldCount(object) : 5;
}

unsigned int LteRlcAmPduDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISARRAY | FD_ISEDITABLE,
    };
    return (field>=0 && field<5) ? fieldTypeFlags[field] : 0;
}

const char *LteRlcAmPduDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "amType",
        "txNumber",
        "firstSn",
        "lastSn",
        "bitmap",
    };
    return (field>=0 && field<5) ? fieldNames[field] : NULL;
}

int LteRlcAmPduDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='a' && strcmp(fieldName, "amType")==0) return base+0;
    if (fieldName[0]=='t' && strcmp(fieldName, "txNumber")==0) return base+1;
    if (fieldName[0]=='f' && strcmp(fieldName, "firstSn")==0) return base+2;
    if (fieldName[0]=='l' && strcmp(fieldName, "lastSn")==0) return base+3;
    if (fieldName[0]=='b' && strcmp(fieldName, "bitmap")==0) return base+4;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *LteRlcAmPduDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "unsigned short",
        "unsigned short",
        "int",
        "int",
        "bool",
    };
    return (field>=0 && field<5) ? fieldTypeStrings[field] : NULL;
}

const char *LteRlcAmPduDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 0:
            if (!strcmp(propertyname,"enum")) return "LteAmType";
            return NULL;
        default: return NULL;
    }
}

int LteRlcAmPduDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    LteRlcAmPdu_Base *pp = (LteRlcAmPdu_Base *)object; (void)pp;
    switch (field) {
        case 4: return pp->getBitmapArraySize();
        default: return 0;
    }
}

std::string LteRlcAmPduDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    LteRlcAmPdu_Base *pp = (LteRlcAmPdu_Base *)object; (void)pp;
    switch (field) {
        case 0: return ulong2string(pp->getAmType());
        case 1: return ulong2string(pp->getTxNumber());
        case 2: return long2string(pp->getFirstSn());
        case 3: return long2string(pp->getLastSn());
        case 4: return bool2string(pp->getBitmap(i));
        default: return "";
    }
}

bool LteRlcAmPduDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    LteRlcAmPdu_Base *pp = (LteRlcAmPdu_Base *)object; (void)pp;
    switch (field) {
        case 0: pp->setAmType(string2ulong(value)); return true;
        case 1: pp->setTxNumber(string2ulong(value)); return true;
        case 2: pp->setFirstSn(string2long(value)); return true;
        case 3: pp->setLastSn(string2long(value)); return true;
        case 4: pp->setBitmap(i,string2bool(value)); return true;
        default: return false;
    }
}

const char *LteRlcAmPduDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    };
}

void *LteRlcAmPduDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    LteRlcAmPdu_Base *pp = (LteRlcAmPdu_Base *)object; (void)pp;
    switch (field) {
        default: return NULL;
    }
}


