//
// Generated file, do not edit! Created by nedtool 4.6 from apps/vod/M1Message.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "M1Message_m.h"

USING_NAMESPACE


// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




// Template rule for outputting std::vector<T> types
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');
    
    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

Register_Class(M1Message);

M1Message::M1Message(const char *name, int kind) : ::cMessage(name,kind)
{
    this->clientPort_var = 0;
    this->numPkSent_var = 0;
}

M1Message::M1Message(const M1Message& other) : ::cMessage(other)
{
    copy(other);
}

M1Message::~M1Message()
{
}

M1Message& M1Message::operator=(const M1Message& other)
{
    if (this==&other) return *this;
    ::cMessage::operator=(other);
    copy(other);
    return *this;
}

void M1Message::copy(const M1Message& other)
{
    this->clientAddr_var = other.clientAddr_var;
    this->clientPort_var = other.clientPort_var;
    this->numPkSent_var = other.numPkSent_var;
}

void M1Message::parsimPack(cCommBuffer *b)
{
    ::cMessage::parsimPack(b);
    doPacking(b,this->clientAddr_var);
    doPacking(b,this->clientPort_var);
    doPacking(b,this->numPkSent_var);
}

void M1Message::parsimUnpack(cCommBuffer *b)
{
    ::cMessage::parsimUnpack(b);
    doUnpacking(b,this->clientAddr_var);
    doUnpacking(b,this->clientPort_var);
    doUnpacking(b,this->numPkSent_var);
}

IPvXAddress& M1Message::getClientAddr()
{
    return clientAddr_var;
}

void M1Message::setClientAddr(const IPvXAddress& clientAddr)
{
    this->clientAddr_var = clientAddr;
}

int M1Message::getClientPort() const
{
    return clientPort_var;
}

void M1Message::setClientPort(int clientPort)
{
    this->clientPort_var = clientPort;
}

long M1Message::getNumPkSent() const
{
    return numPkSent_var;
}

void M1Message::setNumPkSent(long numPkSent)
{
    this->numPkSent_var = numPkSent;
}

class M1MessageDescriptor : public cClassDescriptor
{
  public:
    M1MessageDescriptor();
    virtual ~M1MessageDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(M1MessageDescriptor);

M1MessageDescriptor::M1MessageDescriptor() : cClassDescriptor("M1Message", "cMessage")
{
}

M1MessageDescriptor::~M1MessageDescriptor()
{
}

bool M1MessageDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<M1Message *>(obj)!=NULL;
}

const char *M1MessageDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int M1MessageDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 3+basedesc->getFieldCount(object) : 3;
}

unsigned int M1MessageDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISCOMPOUND,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<3) ? fieldTypeFlags[field] : 0;
}

const char *M1MessageDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "clientAddr",
        "clientPort",
        "numPkSent",
    };
    return (field>=0 && field<3) ? fieldNames[field] : NULL;
}

int M1MessageDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='c' && strcmp(fieldName, "clientAddr")==0) return base+0;
    if (fieldName[0]=='c' && strcmp(fieldName, "clientPort")==0) return base+1;
    if (fieldName[0]=='n' && strcmp(fieldName, "numPkSent")==0) return base+2;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *M1MessageDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "IPvXAddress",
        "int",
        "long",
    };
    return (field>=0 && field<3) ? fieldTypeStrings[field] : NULL;
}

const char *M1MessageDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int M1MessageDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    M1Message *pp = (M1Message *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string M1MessageDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    M1Message *pp = (M1Message *)object; (void)pp;
    switch (field) {
        case 0: {std::stringstream out; out << pp->getClientAddr(); return out.str();}
        case 1: return long2string(pp->getClientPort());
        case 2: return long2string(pp->getNumPkSent());
        default: return "";
    }
}

bool M1MessageDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    M1Message *pp = (M1Message *)object; (void)pp;
    switch (field) {
        case 1: pp->setClientPort(string2long(value)); return true;
        case 2: pp->setNumPkSent(string2long(value)); return true;
        default: return false;
    }
}

const char *M1MessageDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 0: return opp_typename(typeid(IPvXAddress));
        default: return NULL;
    };
}

void *M1MessageDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    M1Message *pp = (M1Message *)object; (void)pp;
    switch (field) {
        case 0: return (void *)(&pp->getClientAddr()); break;
        default: return NULL;
    }
}


