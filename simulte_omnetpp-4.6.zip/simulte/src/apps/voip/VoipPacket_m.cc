//
// Generated file, do not edit! Created by nedtool 4.6 from apps/voip/VoipPacket.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "VoipPacket_m.h"

USING_NAMESPACE


// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




// Template rule for outputting std::vector<T> types
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');
    
    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

Register_Class(VoipPacket);

VoipPacket::VoipPacket(const char *name, int kind) : ::cPacket(name,kind)
{
    this->IDtalk_var = 0;
    this->nframes_var = 0;
    this->IDframe_var = 0;
    this->timestamp_var = 0;
    this->arrivalTime_var = 0;
    this->playoutTime_var = 0;
    this->size_var = 0;
}

VoipPacket::VoipPacket(const VoipPacket& other) : ::cPacket(other)
{
    copy(other);
}

VoipPacket::~VoipPacket()
{
}

VoipPacket& VoipPacket::operator=(const VoipPacket& other)
{
    if (this==&other) return *this;
    ::cPacket::operator=(other);
    copy(other);
    return *this;
}

void VoipPacket::copy(const VoipPacket& other)
{
    this->IDtalk_var = other.IDtalk_var;
    this->nframes_var = other.nframes_var;
    this->IDframe_var = other.IDframe_var;
    this->timestamp_var = other.timestamp_var;
    this->arrivalTime_var = other.arrivalTime_var;
    this->playoutTime_var = other.playoutTime_var;
    this->size_var = other.size_var;
}

void VoipPacket::parsimPack(cCommBuffer *b)
{
    ::cPacket::parsimPack(b);
    doPacking(b,this->IDtalk_var);
    doPacking(b,this->nframes_var);
    doPacking(b,this->IDframe_var);
    doPacking(b,this->timestamp_var);
    doPacking(b,this->arrivalTime_var);
    doPacking(b,this->playoutTime_var);
    doPacking(b,this->size_var);
}

void VoipPacket::parsimUnpack(cCommBuffer *b)
{
    ::cPacket::parsimUnpack(b);
    doUnpacking(b,this->IDtalk_var);
    doUnpacking(b,this->nframes_var);
    doUnpacking(b,this->IDframe_var);
    doUnpacking(b,this->timestamp_var);
    doUnpacking(b,this->arrivalTime_var);
    doUnpacking(b,this->playoutTime_var);
    doUnpacking(b,this->size_var);
}

unsigned int VoipPacket::getIDtalk() const
{
    return IDtalk_var;
}

void VoipPacket::setIDtalk(unsigned int IDtalk)
{
    this->IDtalk_var = IDtalk;
}

unsigned int VoipPacket::getNframes() const
{
    return nframes_var;
}

void VoipPacket::setNframes(unsigned int nframes)
{
    this->nframes_var = nframes;
}

unsigned int VoipPacket::getIDframe() const
{
    return IDframe_var;
}

void VoipPacket::setIDframe(unsigned int IDframe)
{
    this->IDframe_var = IDframe;
}

simtime_t VoipPacket::getTimestamp() const
{
    return timestamp_var;
}

void VoipPacket::setTimestamp(simtime_t timestamp)
{
    this->timestamp_var = timestamp;
}

simtime_t VoipPacket::getArrivalTime() const
{
    return arrivalTime_var;
}

void VoipPacket::setArrivalTime(simtime_t arrivalTime)
{
    this->arrivalTime_var = arrivalTime;
}

simtime_t VoipPacket::getPlayoutTime() const
{
    return playoutTime_var;
}

void VoipPacket::setPlayoutTime(simtime_t playoutTime)
{
    this->playoutTime_var = playoutTime;
}

unsigned int VoipPacket::getSize() const
{
    return size_var;
}

void VoipPacket::setSize(unsigned int size)
{
    this->size_var = size;
}

class VoipPacketDescriptor : public cClassDescriptor
{
  public:
    VoipPacketDescriptor();
    virtual ~VoipPacketDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(VoipPacketDescriptor);

VoipPacketDescriptor::VoipPacketDescriptor() : cClassDescriptor("VoipPacket", "cPacket")
{
}

VoipPacketDescriptor::~VoipPacketDescriptor()
{
}

bool VoipPacketDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<VoipPacket *>(obj)!=NULL;
}

const char *VoipPacketDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int VoipPacketDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 7+basedesc->getFieldCount(object) : 7;
}

unsigned int VoipPacketDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<7) ? fieldTypeFlags[field] : 0;
}

const char *VoipPacketDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "IDtalk",
        "nframes",
        "IDframe",
        "timestamp",
        "arrivalTime",
        "playoutTime",
        "size",
    };
    return (field>=0 && field<7) ? fieldNames[field] : NULL;
}

int VoipPacketDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='I' && strcmp(fieldName, "IDtalk")==0) return base+0;
    if (fieldName[0]=='n' && strcmp(fieldName, "nframes")==0) return base+1;
    if (fieldName[0]=='I' && strcmp(fieldName, "IDframe")==0) return base+2;
    if (fieldName[0]=='t' && strcmp(fieldName, "timestamp")==0) return base+3;
    if (fieldName[0]=='a' && strcmp(fieldName, "arrivalTime")==0) return base+4;
    if (fieldName[0]=='p' && strcmp(fieldName, "playoutTime")==0) return base+5;
    if (fieldName[0]=='s' && strcmp(fieldName, "size")==0) return base+6;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *VoipPacketDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "unsigned int",
        "unsigned int",
        "unsigned int",
        "simtime_t",
        "simtime_t",
        "simtime_t",
        "unsigned int",
    };
    return (field>=0 && field<7) ? fieldTypeStrings[field] : NULL;
}

const char *VoipPacketDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int VoipPacketDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    VoipPacket *pp = (VoipPacket *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string VoipPacketDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    VoipPacket *pp = (VoipPacket *)object; (void)pp;
    switch (field) {
        case 0: return ulong2string(pp->getIDtalk());
        case 1: return ulong2string(pp->getNframes());
        case 2: return ulong2string(pp->getIDframe());
        case 3: return double2string(pp->getTimestamp());
        case 4: return double2string(pp->getArrivalTime());
        case 5: return double2string(pp->getPlayoutTime());
        case 6: return ulong2string(pp->getSize());
        default: return "";
    }
}

bool VoipPacketDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    VoipPacket *pp = (VoipPacket *)object; (void)pp;
    switch (field) {
        case 0: pp->setIDtalk(string2ulong(value)); return true;
        case 1: pp->setNframes(string2ulong(value)); return true;
        case 2: pp->setIDframe(string2ulong(value)); return true;
        case 3: pp->setTimestamp(string2double(value)); return true;
        case 4: pp->setArrivalTime(string2double(value)); return true;
        case 5: pp->setPlayoutTime(string2double(value)); return true;
        case 6: pp->setSize(string2ulong(value)); return true;
        default: return false;
    }
}

const char *VoipPacketDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    };
}

void *VoipPacketDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    VoipPacket *pp = (VoipPacket *)object; (void)pp;
    switch (field) {
        default: return NULL;
    }
}


